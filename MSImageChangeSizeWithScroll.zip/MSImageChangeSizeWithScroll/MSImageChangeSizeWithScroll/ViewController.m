//
//  ViewController.m
//  MSImageChangeSizeWithScroll
//
//  Created by Misheral on 2017/4/27.
//  Copyright © 2017年 Misheral. All rights reserved.
//

#import "ViewController.h"

#define kTableHeaderImageHeight 80

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, weak)  UIView *headerView;
@property (nonatomic, weak) UIImageView *headerImageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:self.tableView];
    
    [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:NSStringFromClass([UITableViewCell class])];
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, -kTableHeaderImageHeight, CGRectGetWidth(self.view.bounds), kTableHeaderImageHeight)];
    view.backgroundColor = [UIColor redColor];
    self.headerView = view;
    [self.tableView addSubview:self.headerView];
    
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:view.bounds];
    imageView.contentMode = UIViewContentModeScaleToFill;
    imageView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    imageView.image = [UIImage imageNamed:@"headerImage.jpg"];
    self.headerImageView = imageView;
    [self.headerView addSubview:self.headerImageView];
    
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.contentInset = UIEdgeInsetsMake(kTableHeaderImageHeight, 0, 0, 0);
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 10.f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44.f;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([UITableViewCell class])];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    CGPoint point = scrollView.contentOffset;
    CGFloat offsetY = point.y;
    CGRect rect = self.headerView.frame;
    if (offsetY <= 0) {
        offsetY = offsetY < -kTableHeaderImageHeight ? offsetY : -kTableHeaderImageHeight;
        rect.origin.y = offsetY;
        rect.size.height = -offsetY;
    }
    self.headerView.frame = rect;
}

@end
